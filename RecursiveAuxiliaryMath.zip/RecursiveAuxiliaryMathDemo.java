package recursiveauxiliarymath;
import java.util.Scanner;
/**
 * Brandon Logan
 * CSC 1351-02
 * Spring 2023
 * Lab 6
 */
public class RecursiveAuxiliaryMathDemo {
    
    public static void main(String[] args){
        
    Scanner in = new Scanner(System.in);
    System.out.print("Enter three integers whose GCD is to be found -> ");
    int num1 = in.nextInt();
    int num2 = in.nextInt();
    int num3 = in.nextInt();        
    System.out.print("Enter an integer n to sum the fibonacci series up to"
        + " fibonacci(n) -> ");
    int n = in.nextInt();   
    System.out.print("Enter a base != 0 (double) and"
            + " an exponent != 0 (integer)" + " -> ");
    double base = in.nextDouble();
    int exp = in.nextInt();   
    System.out.print("Enter two positive integers i and j where i < j -> ");
    int i = in.nextInt();
    int j = in.nextInt();
        
    int gcd12 = RecursiveAuxiliaryMath.recursiveGCD(num1, num2);
    int gcd123 = RecursiveAuxiliaryMath.recursiveGCD(gcd12, num3);
    
    long sumFibonacci = 0;
    for(int k = 1; k <= n; k++)
    {    
        sumFibonacci += RecursiveAuxiliaryMath.recursiveFibonacci(k);
    }
    
    int absExp = Math.abs(exp);
    double exponential=RecursiveAuxiliaryMath.recursivePowInt(base, absExp);
    if(exp < 0)
    {
        exponential = 1 / exponential;
    }
        
    int numPalindrome = 0;
    for(int k = i; k <= j; k++)
    {
        String num = "" + k;
        if(RecursiveAuxiliaryMath.recursiveIsPalindrome(num, 0, num.length()-1))
        {
            numPalindrome++;
        }
    }
    
    System.out.println();
    System.out.printf("gcd(%d,%d,%d) = %d\n", num1, num2, num3, gcd123);
    System.out.printf("Sum up to fibonacci(%d) = %d\n", n, sumFibonacci);
    System.out.printf("%.6f ^ %d = %.6f\n", base, exp, exponential);
    System.out.printf("There are %d palindromic numbers between %d and %d\n", 
                       numPalindrome, i, j);
  }
}
