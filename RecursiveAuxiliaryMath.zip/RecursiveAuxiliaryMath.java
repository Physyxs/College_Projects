package recursiveauxiliarymath;
/**
 * Brandon Logan
 * CSC 1351-02
 * Spring 2023
 * Lab 6
 */
public class RecursiveAuxiliaryMath {

    public static boolean recursiveIsPalindrome(String num, int i, int j)
    {
        if (i >= j)
        {
            return true;
        }
        else
        {
            char first = num.charAt(i);
            char last = num.charAt(j);
            if (Character.isDigit(first) && Character.isDigit(last))
            {
                if (first == last)
                {
                    return recursiveIsPalindrome(num, i + 1, j - 1);
                }
                else
                {
                    return false;
                }
            }
            else if (!Character.isDigit(last))
            {
                return recursiveIsPalindrome(num, i, j - 1);
            }
            else
            {
                return recursiveIsPalindrome(num, i + 1, j);
            }
        }
    }
    
    public static long recursiveFibonacci(int n)
    {
        return switch (n) {
            case 0 -> 0;
            case 1 -> 1;
            default -> recursiveFibonacci(n-1) + recursiveFibonacci(n-2);
        };
    }
    
    public static int recursiveGCD(int a, int b)
    {
        if(a < 0) a *= -1;
        if(b < 0) b *= -1;
        if(b == 0) return a;
        
        return recursiveGCD(b, a % b);
    }
    
    public static double recursivePowInt(double a, int n)
    {
        if (n == 0) {
            return 1;
        }
        double result = recursivePowInt(a, n / 2);
        if (n % 2 == 0) {
            return result * result;
        } else {
            return result * result * a;
        }
    }
    
}
