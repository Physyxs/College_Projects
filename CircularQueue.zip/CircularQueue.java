package circularqueue;

public class CircularQueue<E> implements CircularQueueInterface<E>
{
    private Node rear;
    private int length;

    
    /**
     * this inner class is used to create nodes of a singly-linked queue
     */
    private class Node
    {
       public E data;
       public Node next;
    }

    
    /**
     * Creates an empty singly-linked queue
     */
    public CircularQueue()
    {
        length = 0;
        rear = null;
    }

    
    public int size()
    {
        return length;
    }

    
    /**
     * Determines whether the queue is empty.
     * @return true if the queue is empty;
     * otherwise, false
     */
    public boolean isEmpty()
    {
        return rear == null;
    }

    
    /**
     * Inserts an item at the rear of the queue.
     * @param data the value to be inserted.
     */
    public void enqueue(E data)
    {
        Node newNode = new Node();
        newNode.data = data;
        if (rear == null) {
            newNode.next = newNode;
            rear = newNode;
        } else {
            newNode.next = rear.next;
            rear.next = newNode;
            rear = newNode;
        }
        length++;
              
    }

    
    /**
     * Accesses the item at the head of a non-empty queue
     * @return item at the head of the queue.
     * @throws Exception when this queue is empty
     */
    public E front() throws Exception
    {
        return rear.next.data;
    }

    
    /**
     * Deletes the item at the head of the queue.
     * @return item at the head of the queue.
     * @throws Exception when this queue is empty
     */
    public E dequeue() throws Exception
    {
       if (rear == null) {
            return null;
        }
        Node front = rear.next;
        E value = front.data;
        if (rear == front) {
            rear = null;
        } else {
            rear.next = front.next;
        }
        front.next = null;
        length--;
        return value;
    }


    /**
     * Moves the node at the rear of the queue to the head.
     */
    public void rotateCounterclockwise()
    {
        if (rear != null) {
            rear = rear.next;
            Node current = rear;
            int i = 0;
            while (i<length-2) {
                current = current.next;
                i++;
            }
            rear = current;
        }
    }

    
    /**
     * Moves the node at the head of the queue to the rear.
     */
    public void rotateClockwise()
    {
        if (rear != null) {
            rear = rear.next;
        }
    }

    
    /**
     * Returns a string [en-1, ..., e2, e1, e0] representing this queue, 
     * where e0 is the data item in the head node and en-1 is the data item
     * in the rear node. It returns [] if this queue is empty.     
     */	 
    public String toString()
    {
        if (rear == null) {
        return "[]";
        }
        StringBuilder sb = new StringBuilder("[");
        Node current = rear;
        do {
            current = current.next;
            sb.insert(1, current.data + ", ");
        } while (current != rear);
        sb.delete(sb.length() - 2, sb.length());
        sb.append("]");
        return sb.toString();

    }	    
}
