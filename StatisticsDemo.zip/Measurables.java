/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package statisticsdemo;

/**
 *
 * @author brand
 */
public interface Measurables {
    public int getFirstInt();
    public int getSecondInt();
    public int getThirdInt();
    public double getDouble();
}
