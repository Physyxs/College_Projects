/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package statisticsdemo;

/**
 *
 * @author brand
 */
public class Employee implements Measurables, Comparable{
    private String name;
    private int hours;
    private int rate;
    private int sales;
    private double netPay;
    
    public Employee(String name, int hours, int rate, int sales){
        this.name = name;
        this.hours = hours;
        this.rate = rate;
        this.sales = sales;
        netPay = hours*rate + sales*0.15;
        netPay -= netPay*0.18;
    }
    
    public int getFirstInt(){
        return hours;
    }
    public int getSecondInt(){
        return rate;
    }
    public int getThirdInt(){
        return sales;
    }
    public double getDouble(){
        return netPay;
    }
    public int compareTo(Object otherObject){
        Employee other = (Employee) otherObject;
        return (int) netPay - (int) other.getDouble();
    }
    public String toString(){
        String output = String.format("%-4s",name) + " Hours=" + hours + ",Rate=$" + rate;
        output += ",Sales=$" + sales + ",Net Pay=$" + String.format("%.2f",netPay);
        output = "\n(" + output + ")";
        return output;
    }
    
}
